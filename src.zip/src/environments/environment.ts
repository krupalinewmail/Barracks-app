export const environment = {
    baseURL: "https://mvp.barracks.army"
};
