export interface UserDetail {
    email: string;
    password: string;
}