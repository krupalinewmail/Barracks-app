import { Injectable } from '@angular/core';
import { UserDetail } from '../models/user';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment.development';
import { password, username } from '../../shared/constant';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  baseURL = environment.baseURL;

  constructor(private  httpClient:HttpClient) { }
  authenticateUser(userDetail: UserDetail): any {
    let authorizationData = 'Basic ' + btoa(username + ':' + password);

const headerOptions = {
    headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': authorizationData,
        'Accept-Encoding': 'gzip, deflate, br'
    })
};
    return this.httpClient.post(`${this.baseURL}/api/v1/users/login`,userDetail,headerOptions);
  }
  registerUser(userDetail: any): any{
    let authorizationData = 'Basic ' + btoa(username + ':' + password);

    const headerOptions = {
        headers: new HttpHeaders({
            'Content-Type':  'application/json',
            'Accept-Encoding': 'gzip, deflate, br',
            'Authorization': authorizationData,
            
            
        })
    };
        return this.httpClient.post(`${this.baseURL}/api/v1/users/signup`,userDetail,headerOptions);
  }
}
