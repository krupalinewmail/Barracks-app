import { RouterModule, Routes } from '@angular/router';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

export const routes: Routes = [
    { path: '', redirectTo: '', pathMatch: 'full' },
    { path: '', loadChildren: () => import('./auth/auth.module').then(m => m.AuthModule) },
    { path: '**', component: PageNotFoundComponent }
];

export const routing = RouterModule.forRoot(routes);
